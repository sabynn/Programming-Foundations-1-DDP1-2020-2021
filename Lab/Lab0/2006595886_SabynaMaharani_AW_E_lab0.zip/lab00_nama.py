nama = input("Masukkan nama kamu: ")
nama_panggilan = input("Masukkan nama panggilan kamu: ")
print("Nama saya, " + nama)
print("Kamu bisa panggil saya", nama_panggilan)

